
package modelo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Fresco {

    @SerializedName("producto")
    @Expose
    private String producto;
    @SerializedName("fechaCaducidad")
    @Expose
    private String fechaCaducidad;
    @SerializedName("noLote")
    @Expose
    private Integer noLote;
    @SerializedName("paisOrigen")
    @Expose
    private String paisOrigen;
    @SerializedName("fechaEnvasado")
    @Expose
    private String fechaEnvasado;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Fresco() {
        
        
    }

    /**
     * 
     * @param noLote
     * @param fechaCaducidad
     * @param producto
     * @param paisOrigen
     * @param fechaEnvasado
     */
    public Fresco(String producto, String fechaCaducidad, Integer noLote, String paisOrigen, String fechaEnvasado) {
        super();
        this.producto = producto;
        this.fechaCaducidad = fechaCaducidad;
        this.noLote = noLote;
        this.paisOrigen = paisOrigen;
        this.fechaEnvasado = fechaEnvasado;
    }

    
    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public Integer getNoLote() {
        return noLote;
    }

    public void setNoLote(Integer noLote) {
        this.noLote = noLote;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public String getFechaEnvasado() {
        return fechaEnvasado;
    }

    public void setFechaEnvasado(String fechaEnvasado) {
        this.fechaEnvasado = fechaEnvasado;
    }

}


package modelo;
import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Producto {

    @SerializedName("fresco")
    @Expose
    private List<Fresco> fresco = null;
    @SerializedName("refrigerado")
    @Expose
    private List<Refrigerado> refrigerado = null;
    @SerializedName("congeladosAire")
    @Expose
    private List<CongeladosAire> congeladosAire = null;
    @SerializedName("congeladosAgua")
    @Expose
    private List<CongeladosAgua> congeladosAgua = null;
    @SerializedName("congeladosNitrogeno")
    @Expose
    private List<CongeladosNitrogeno> congeladosNitrogeno = null;

    /**
     * No args constructor for use in serialization
     * 
     */
    public Producto() {
    }

    /**
     * 
     * @param congeladosNitrogeno
     * @param congeladosAgua
     * @param fresco
     * @param refrigerado
     * @param congeladosAire
     */
    public Producto(List<Fresco> fresco, List<Refrigerado> refrigerado, List<CongeladosAire> congeladosAire, List<CongeladosAgua> congeladosAgua, List<CongeladosNitrogeno> congeladosNitrogeno) {
        super();
        this.fresco = fresco;
        this.refrigerado = refrigerado;
        this.congeladosAire = congeladosAire;
        this.congeladosAgua = congeladosAgua;
        this.congeladosNitrogeno = congeladosNitrogeno;
    }

    
    public List<Fresco> getFresco() {
        return fresco;
    }

    public void setFresco(List<Fresco> fresco) {
        this.fresco = fresco;
    }

    public List<Refrigerado> getRefrigerado() {
        return refrigerado;
    }

    public void setRefrigerado(List<Refrigerado> refrigerado) {
        this.refrigerado = refrigerado;
    }

    public List<CongeladosAire> getCongeladosAire() {
        return congeladosAire;
    }

    public void setCongeladosAire(List<CongeladosAire> congeladosAire) {
        this.congeladosAire = congeladosAire;
    }

    public List<CongeladosAgua> getCongeladosAgua() {
        return congeladosAgua;
    }

    public void setCongeladosAgua(List<CongeladosAgua> congeladosAgua) {
        this.congeladosAgua = congeladosAgua;
    }

    public List<CongeladosNitrogeno> getCongeladosNitrogeno() {
        return congeladosNitrogeno;
    }

    public void setCongeladosNitrogeno(List<CongeladosNitrogeno> congeladosNitrogeno) {
        this.congeladosNitrogeno = congeladosNitrogeno;
    }

}


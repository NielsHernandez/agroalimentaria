
package modelo;

//Searilizar = escritura de archivos JSON y Deserializar = lectura

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


//implementar una interface el nombre de la interface Serializable

public class GenerarJson implements Serializable{
    //GenerarJson miJson = new GenerarJson();
    //voy a utilizar una lista statica
    
    static List<Producto> myList;
    
    
    //crear un metodo para obtener la informacion 
    
    public static List<Producto> readJson() throws FileNotFoundException, IOException{
        
        //indicarle la ruta donde se guarda el archivo JSON
        
        String filePath = new File("c:\\temp\\productos.json").toString();
        
        //Creacion de objeto propio de la libreria GSON
        
        JsonParser parser = new JsonParser();
        
        //leer el archivo .json
        
        FileReader fr = new FileReader(filePath);
        
        // el JsonElement rescata los datos del archivo JSON por medio de un parser previamente declarado
        JsonElement datos = parser.parse(fr);
        //variable tipo String para almacenar la info del archivo Json temporalmente
        
        String productosJson = datos.toString();
        
        //cerrar el archivo de segundo plano
        fr.close();
        
        //finalmente crear los objetos leibles por java Usando un  Objeto tipo Gson
        //declarado unicamente, vamos a utilizar algunos de sus metodos para manipular la info del .json
        Gson gson = new Gson();
        //delcarar un lugar donde almacenarlos en codigo java
        //usaremos el objeto gson previamente declarado para convertir los datos almacenados
        //temporalmente en objetos del tipo producto, de Json a Objetos java (son los datos, del tipo a utilizar)
        Producto[] objProducto = gson.fromJson(productosJson, Producto[].class);
        
        //declar la lista donde se almacena todos los objetos del archivo json
        
        myList = new ArrayList<>();
        
        //usar un bucle foreach para recorrer los objetos Json
        
        for(Producto item : objProducto)
        {
            Producto p = new Producto(item.getFresco(),
                    item.getRefrigerado(),item.getCongeladosAire(),item.getCongeladosAgua(),item.getCongeladosNitrogeno());
            
            myList.add(p);
        }
        
 
        return myList;
    }
    
    
    
    //directorio donde se encuentra el archivo JSON
    //ruta especifica
    //no genera problemas con exceptions del tipo filenotfounded
    
    
    
    
}

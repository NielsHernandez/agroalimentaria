/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.io.IOException;

/**
 *
 * @author niels
 */
public class Prueba {
    
    public static void main(String [] args) throws IOException
    {
        
        for(Producto p : GenerarJson.readJson())
        {
            //crear otro for para leer cualquier tipo de producto ya sea fresco etc.
            
            for(Fresco fres : p.getFresco())
            {
                System.out.println(fres.getProducto());
            }
            
            for(Refrigerado ref : p.getRefrigerado())
            {
                System.out.println(ref.getProducto());
            }
            
            for(CongeladosAire cAire : p.getCongeladosAire())
            {
                System.out.println(cAire.getProducto());
            }
            
            for(CongeladosAgua cAgua : p.getCongeladosAgua())
            {
                System.out.println(cAgua.getProducto());
            }
            
            for(CongeladosNitrogeno cNitrogeno : p.getCongeladosNitrogeno())
            {
                System.out.println(cNitrogeno.getProducto());
            }
        }
    }
    
}

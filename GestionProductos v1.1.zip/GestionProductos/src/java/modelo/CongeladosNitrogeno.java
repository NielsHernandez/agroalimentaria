
package modelo;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class CongeladosNitrogeno {

    @SerializedName("producto")
    @Expose
    private String producto;
    @SerializedName("fechaCaducidad")
    @Expose
    private String fechaCaducidad;
    @SerializedName("noLote")
    @Expose
    private Integer noLote;
    @SerializedName("paisOrigen")
    @Expose
    private String paisOrigen;
    @SerializedName("fechaEnvasado")
    @Expose
    private String fechaEnvasado;
    @SerializedName("temperatura")
    @Expose
    private Integer temperatura;
    @SerializedName("metodo")
    @Expose
    private String metodo;
    @SerializedName("tiempo")
    @Expose
    private Integer tiempo;

    /**
     * No args constructor for use in serialization
     * 
     */
    public CongeladosNitrogeno() {
    }

    /**
     * 
     * @param noLote
     * @param fechaCaducidad
     * @param tiempo
     * @param producto
     * @param paisOrigen
     * @param metodo
     * @param temperatura
     * @param fechaEnvasado
     */
    public CongeladosNitrogeno(String producto, String fechaCaducidad, Integer noLote, String paisOrigen, String fechaEnvasado, Integer temperatura, String metodo, Integer tiempo) {
        super();
        this.producto = producto;
        this.fechaCaducidad = fechaCaducidad;
        this.noLote = noLote;
        this.paisOrigen = paisOrigen;
        this.fechaEnvasado = fechaEnvasado;
        this.temperatura = temperatura;
        this.metodo = metodo;
        this.tiempo = tiempo;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(String fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public Integer getNoLote() {
        return noLote;
    }

    public void setNoLote(Integer noLote) {
        this.noLote = noLote;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public void setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
    }

    public String getFechaEnvasado() {
        return fechaEnvasado;
    }

    public void setFechaEnvasado(String fechaEnvasado) {
        this.fechaEnvasado = fechaEnvasado;
    }

    public Integer getTemperatura() {
        return temperatura;
    }

    public void setTemperatura(Integer temperatura) {
        this.temperatura = temperatura;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public Integer getTiempo() {
        return tiempo;
    }

    public void setTiempo(Integer tiempo) {
        this.tiempo = tiempo;
    }

}
